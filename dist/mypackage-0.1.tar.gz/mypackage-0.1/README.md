# mypackage
This library was created to show a brother how to publish one's own Python package

## Building this package locally
'python setup.py sdist'

## installing this package from GitHub
'pip install git+ (insert link here)'

##  updating this package from GitHub
'pip install -- upgrade git+(insert same link as above)' 
